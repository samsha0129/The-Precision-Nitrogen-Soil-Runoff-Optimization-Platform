"""
nitrogen_model.py — Phase 3 of the Precision Nitrogen & Soil Runoff Optimization Platform.

Dual-objective nitrogen recommendation per management zone:
  Output 1  Marginal crop biomass gain (kg DM/ha) from an added N dose
  Output 2  Leaching/runoff risk (0-1): probability that more than `loss_threshold_kg`
            of the applied N leaves the root zone (drainage) or the field (runoff) during
            the forecast window, integrated over forecast uncertainty.
  N_opt     = the smallest rate reaching the best feasible biomass gain subject to risk < 0.15.

Architecture (why a simulator + surrogate)
-----------------------------------------
There is no public dataset that pairs zone-level N rates with *both* yield response and
measured leaching under a known 5-day forecast. So:
  1. A transparent process simulator (bucket water balance per zone, mixing-cell nitrate
     displacement, infiltration/saturation-excess runoff, denitrification under saturation,
     quadratic-plateau crop response) is the "teacher". Its yield-response parameters can be
     calibrated on real N-rate trials: the PRNT dataset (Ransom et al. 2021, 49 US Midwest
     corn site-years, 16 N rates; Dryad doi:10.5061/dryad.66t1g1k2g) via `calibrate`.
  2. The simulator (Monte-Carlo over rainfall forecast error) labels a large, diverse
     training set; an XGBoost dual-output regressor is trained on it with *monotone
     constraints* (more N never lowers gain or risk; more rain never lowers risk), so
     the optimiser searches a smooth, physically consistent surface in milliseconds.
  3. Every recommendation is re-verified with the full simulator before it is returned.

Weather: Open-Meteo daily forecast (precipitation_sum, et0_fao_evapotranspiration),
free, no API key. Irrigation (the dominant leaching driver in e.g. Salinas Valley
vegetables) is an explicit input.

Install
-------
    pip install numpy scipy pandas xgboost scikit-learn   (+ Phase 1/2 dependencies)

CLI
---
    python nitrogen_model.py selftest
    python nitrogen_model.py train --crop corn --samples 40000 --out models/corn
    python nitrogen_model.py recommend --model models/corn --zones out/zones_syn/zone_profile.csv \
        --stage V8-V10 --lat 36.568 --lon -121.525 --prior-n 40 --out out/rx.csv
    python nitrogen_model.py recommend ... --rain 0 4 28 12 0 --et0 5 5 4 3 5   # offline / what-if
    python nitrogen_model.py calibrate --trials prnt_yield.csv --site-col SITEYEAR \
        --n-col NRATE --yield-col YIELD --yield-units bu_ac
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass, field, replace
from datetime import date
from pathlib import Path
from typing import Any, Literal, Sequence

import numpy as np
import numpy.typing as npt
import pandas as pd
from scipy.optimize import curve_fit
from sklearn.metrics import mean_absolute_error, r2_score
from xgboost import XGBRegressor

from clustering import saxton_rawls

LOGGER = logging.getLogger("nitrogen_model")

FloatArray = npt.NDArray[np.float64]
FORECAST_DAYS = 5
RISK_LIMIT = 0.15
KG_HA_TO_LB_AC = 0.892179
BU_AC_CORN_TO_KG_HA = 62.77  # 56 lb bushel
OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"


# --------------------------------------------------------------------------------------
# Crop knowledge
# --------------------------------------------------------------------------------------
@dataclass(frozen=True)
class StageProfile:
    name: str
    code: int
    root_depth_mm: float  # effective rooting depth: drainage below this is leaching
    uptake_window_frac: float  # share of an applied dose the crop takes up within the 5-day window
    remaining_demand_frac: float  # share of season N demand still ahead (late N has less yield effect)
    crop_coeff: float  # Kc applied to reference ET0


@dataclass(frozen=True)
class CropProfile:
    name: str
    stages: tuple[StageProfile, ...]
    ymax_biomass_kg_ha: float  # attainable above-ground dry matter, non-limiting N
    soil_supply_frac: float  # relative yield at zero fertiliser N (check-plot / max)
    n_crit_kg_ha: float  # fertiliser N at the quadratic-plateau join point
    harvest_index: float  # grain (or marketable) : biomass, for profit mode
    max_n_rate_kg_ha: float
    provisional: bool
    source: str

    def stage(self, name: str) -> StageProfile:
        for s in self.stages:
            if s.name.lower() == name.lower():
                return s
        raise ValueError(f"Unknown stage '{name}' for {self.name}; options: {[s.name for s in self.stages]}")

    @property
    def stage_names(self) -> list[str]:
        return [s.name for s in self.stages]


CROPS: dict[str, CropProfile] = {
    "corn": CropProfile(
        name="corn",
        stages=(
            StageProfile("pre-plant", 0, 300.0, 0.00, 1.00, 0.30),
            StageProfile("V4-V6", 1, 450.0, 0.04, 0.95, 0.45),
            StageProfile("V8-V10", 2, 700.0, 0.15, 0.85, 0.80),
            StageProfile("V12-VT", 3, 900.0, 0.25, 0.55, 1.15),
            StageProfile("R1-R2", 4, 1000.0, 0.12, 0.20, 1.20),
        ),
        # PRNT-scale defaults: check-plot yields ~55-60 % of plateau, plateau reached near
        # 180-220 kg N/ha (Ransom et al. 2021; Enrria et al. 2024). Re-fit with `calibrate`.
        ymax_biomass_kg_ha=26_000.0,
        soil_supply_frac=0.56,
        n_crit_kg_ha=195.0,
        harvest_index=0.50,
        max_n_rate_kg_ha=250.0,
        provisional=False,
        source="Defaults at PRNT (US Midwest, 2014-2016) scale; calibrate to local trials.",
    ),
    "lettuce": CropProfile(
        name="lettuce",
        stages=(
            StageProfile("establishment", 0, 200.0, 0.02, 1.00, 0.30),
            StageProfile("rosette", 1, 300.0, 0.08, 0.90, 0.60),
            StageProfile("cupping", 2, 400.0, 0.20, 0.60, 0.90),
            StageProfile("heading", 3, 450.0, 0.25, 0.30, 1.00),
        ),
        ymax_biomass_kg_ha=4_500.0,
        soil_supply_frac=0.50,
        n_crit_kg_ha=170.0,
        harvest_index=0.60,
        max_n_rate_kg_ha=220.0,
        provisional=True,
        source="PROVISIONAL shallow-rooted vegetable profile; validate against UCCE / soil nitrate quick-test guidance.",
    ),
}


# --------------------------------------------------------------------------------------
# Zone + weather inputs
# --------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ZoneConditions:
    zone_id: int
    zone_name: str
    zone_type: str
    area_ha: float
    sand_pct: float
    clay_pct: float
    soc_gkg: float
    awc: float  # m3/m3 (field capacity - wilting point)
    ksat_mm_h: float
    drainage_class: float  # 0 excessively .. 4 poorly drained (zone mean)
    ndvi: float
    moisture_anomaly: float

    @property
    def theta_fc(self) -> float:
        _, fc, _, _ = saxton_rawls(
            np.array([self.sand_pct], np.float32), np.array([self.clay_pct], np.float32), np.array([self.soc_gkg], np.float32)
        )
        return float(fc[0])


def load_zone_profile(path: str | Path) -> list[ZoneConditions]:
    """Read Phase 2 `zone_profile.csv`."""
    return zones_from_dataframe(pd.read_csv(path), source=str(path))


def zones_from_dataframe(df: pd.DataFrame, source: str = "zone profile") -> list[ZoneConditions]:
    """Build ZoneConditions from a Phase 2 profile table (in memory or loaded from CSV)."""
    path = source
    required = ["zone_id", "area_ha", "sand_pct", "clay_pct", "soc_gkg", "awc", "ksat_mm_h", "drainage_class", "ndvi", "moisture_anomaly"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{path} is missing columns {missing}; expected Phase 2 zone_profile.csv")
    zones: list[ZoneConditions] = []
    for r in df.itertuples(index=False):
        zones.append(
            ZoneConditions(
                zone_id=int(r.zone_id),
                zone_name=str(getattr(r, "zone_name", f"Zone {r.zone_id}")),
                zone_type=str(getattr(r, "zone_type", "unknown")),
                area_ha=float(r.area_ha),
                sand_pct=float(r.sand_pct),
                clay_pct=float(r.clay_pct),
                soc_gkg=float(r.soc_gkg),
                awc=float(r.awc),
                ksat_mm_h=float(r.ksat_mm_h),
                drainage_class=float(r.drainage_class),
                ndvi=float(r.ndvi),
                moisture_anomaly=float(r.moisture_anomaly),
            )
        )
    return zones


@dataclass(frozen=True)
class WeatherWindow:
    dates: tuple[str, ...]
    precip_mm: tuple[float, ...]
    et0_mm: tuple[float, ...]
    irrigation_mm: tuple[float, ...]
    source: str

    def __post_init__(self) -> None:
        for name in ("precip_mm", "et0_mm", "irrigation_mm"):
            if len(getattr(self, name)) != FORECAST_DAYS:
                raise ValueError(f"{name} must have {FORECAST_DAYS} values")


def fetch_open_meteo_forecast(lat: float, lon: float, timeout_s: float = 20.0) -> WeatherWindow:
    """5-day daily precipitation and FAO-56 reference ET from Open-Meteo (no API key)."""
    params = {
        "latitude": f"{lat:.5f}",
        "longitude": f"{lon:.5f}",
        "daily": "precipitation_sum,et0_fao_evapotranspiration",
        "forecast_days": str(FORECAST_DAYS),
        "timezone": "auto",
    }
    url = f"{OPEN_METEO_URL}?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(url, timeout=timeout_s) as resp:  # noqa: S310 - fixed https endpoint
        payload = json.loads(resp.read().decode())
    daily = payload["daily"]
    precip = [float(v or 0.0) for v in daily["precipitation_sum"]][:FORECAST_DAYS]
    et0 = [float(v or 0.0) for v in daily["et0_fao_evapotranspiration"]][:FORECAST_DAYS]
    return WeatherWindow(
        dates=tuple(daily["time"][:FORECAST_DAYS]),
        precip_mm=tuple(precip),
        et0_mm=tuple(et0),
        irrigation_mm=(0.0,) * FORECAST_DAYS,
        source=f"open-meteo ({lat:.4f}, {lon:.4f})",
    )


def manual_weather(precip: Sequence[float], et0: Sequence[float] | None = None, irrigation: Sequence[float] | None = None) -> WeatherWindow:
    today = date.today()
    return WeatherWindow(
        dates=tuple((today.fromordinal(today.toordinal() + i)).isoformat() for i in range(FORECAST_DAYS)),
        precip_mm=tuple(float(v) for v in precip),
        et0_mm=tuple(float(v) for v in (et0 or [4.0] * FORECAST_DAYS)),
        irrigation_mm=tuple(float(v) for v in (irrigation or [0.0] * FORECAST_DAYS)),
        source="manual",
    )


# --------------------------------------------------------------------------------------
# Process simulator (the "teacher")
# --------------------------------------------------------------------------------------
@dataclass(frozen=True)
class SimulatorConfig:
    loss_threshold_kg: float = 10.0  # N lost from the applied dose that counts as a leaching/runoff event
    n_draws: int = 128
    rain_cv_day1: float = 0.35  # lognormal forecast-error sigma, grows with lead time
    rain_cv_growth: float = 0.10
    surprise_rain_prob: float = 0.06
    surprise_rain_mean_mm: float = 6.0
    rain_duration_h: float = 6.0  # rainfall assumed concentrated over this many hours (infiltration excess)
    runoff_n_coeff: float = 0.010  # fraction of exposed surface N lost per mm runoff (exponential)
    denit_coeff: float = 0.035  # per saturated day
    seed: int = 7


SIM_INPUT_COLUMNS: tuple[str, ...] = (
    "sand_pct",
    "clay_pct",
    "soc_gkg",
    "awc",
    "theta_fc",
    "ksat_mm_h",
    "drainage_class",
    "ndvi",
    "moisture_anomaly",
    "stage_code",
    "prior_n",
    "n_rate",
)


def _stage_arrays(crop: CropProfile, stage_code: FloatArray) -> dict[str, FloatArray]:
    codes = stage_code.astype(int)
    lut = {s.code: s for s in crop.stages}
    return {
        "root": np.array([lut[c].root_depth_mm for c in codes], dtype=np.float64),
        "uptake": np.array([lut[c].uptake_window_frac for c in codes], dtype=np.float64),
        "remaining": np.array([lut[c].remaining_demand_frac for c in codes], dtype=np.float64),
        "kc": np.array([lut[c].crop_coeff for c in codes], dtype=np.float64),
    }


def crop_response(crop: CropProfile, eff_n: FloatArray, sand: FloatArray, awc: FloatArray, soc: FloatArray, ndvi: FloatArray, drainage: FloatArray) -> FloatArray:
    """Quadratic-plateau biomass (kg DM/ha) as a function of *effective* fertiliser N."""
    water = np.clip(0.75 + 1.8 * (awc - 0.10), 0.70, 1.10)
    vigor = np.clip(0.80 + 0.40 * (ndvi - 0.50), 0.70, 1.10)
    anoxia = 1.0 - 0.10 * np.clip(drainage - 2.5, 0.0, 1.5)
    ymax = crop.ymax_biomass_kg_ha * water * vigor * anoxia
    f0 = np.clip(crop.soil_supply_frac + 0.010 * (soc - 10.0), 0.30, 0.85)
    n_crit = crop.n_crit_kg_ha * (1.0 - f0) / (1.0 - crop.soil_supply_frac)
    ratio = np.clip(eff_n / np.maximum(n_crit, 1.0), 0.0, 1.0)
    return ymax * (f0 + (1.0 - f0) * (1.0 - (1.0 - ratio) ** 2))


def simulate(
    inputs: pd.DataFrame,
    rain: FloatArray,
    et0: FloatArray,
    irrigation: FloatArray,
    crop: CropProfile,
    cfg: SimulatorConfig = SimulatorConfig(),
    rng: np.random.Generator | None = None,
) -> pd.DataFrame:
    """Monte-Carlo simulation of one dose decision per row.

    Returns biomass_gain (mean), leach_risk (P[lost N > threshold]), mean N lost, drainage, runoff.
    """
    rng = rng or np.random.default_rng(cfg.seed)
    n = len(inputs)
    if rain.shape != (n, FORECAST_DAYS) or et0.shape != (n, FORECAST_DAYS) or irrigation.shape != (n, FORECAST_DAYS):
        raise ValueError("rain/et0/irrigation must be (n_rows, 5)")
    g = {c: inputs[c].to_numpy(dtype=np.float64) for c in SIM_INPUT_COLUMNS}
    st = _stage_arrays(crop, g["stage_code"])
    d = cfg.n_draws

    sigma = cfg.rain_cv_day1 + cfg.rain_cv_growth * np.arange(FORECAST_DAYS)
    mult = rng.lognormal(mean=-0.5 * sigma**2, sigma=sigma, size=(d, n, FORECAST_DAYS))
    surprise = (rng.random((d, n, FORECAST_DAYS)) < cfg.surprise_rain_prob) * rng.exponential(cfg.surprise_rain_mean_mm, (d, n, FORECAST_DAYS))
    rain_draw = rain[None] * mult + surprise
    water_in = rain_draw + irrigation[None]

    ksat = np.maximum(g["ksat_mm_h"], 0.01)[None, :]
    cap = (g["awc"] * st["root"])[None, :]  # plant-available storage in the root zone (mm)
    s0_frac = np.clip(0.55 + 0.12 * g["moisture_anomaly"] + 0.06 * (g["drainage_class"] - 2.0), 0.2, 1.0)
    storage = np.broadcast_to(s0_frac * cap[0], (d, n)).copy()
    et_daily = et0 * st["kc"][:, None]

    drain_total = np.zeros((d, n))
    runoff_total = np.zeros((d, n))
    sat_days = np.zeros((d, n))
    infil_cap = ksat * cfg.rain_duration_h
    for day in range(FORECAST_DAYS):
        w = water_in[..., day]
        runoff_ie = np.maximum(0.0, w - infil_cap)
        storage = np.maximum(storage + (w - runoff_ie) - et_daily[None, :, day], 0.0)
        excess = np.maximum(0.0, storage - cap)
        drain = np.minimum(excess, ksat * 24.0)
        sat_excess = excess - drain
        storage = storage - drain - sat_excess
        drain_total += drain
        runoff_total += runoff_ie + sat_excess
        sat_days += (sat_excess > 0.0) | ((excess > 0.0) & (g["drainage_class"][None, :] >= 3.0))

    pore_volume = np.maximum(g["theta_fc"] * st["root"], 1.0)[None, :]
    f_leach = 1.0 - np.exp(-drain_total / pore_volume)
    f_runoff = 1.0 - np.exp(-cfg.runoff_n_coeff * runoff_total)
    exposed = (1.0 - st["uptake"])[None, :]
    n_rate = g["n_rate"][None, :]
    lost = n_rate * exposed * (1.0 - (1.0 - f_leach) * (1.0 - f_runoff))
    f_denit = 1.0 - np.exp(-cfg.denit_coeff * sat_days)
    eff_n = (n_rate - lost) * (1.0 - f_denit * exposed)

    prior = g["prior_n"][None, :]
    args = {k: g[k][None, :] for k in ("sand_pct", "awc", "soc_gkg", "ndvi", "drainage_class")}
    y_with = crop_response(crop, prior + eff_n, args["sand_pct"], args["awc"], args["soc_gkg"], args["ndvi"], args["drainage_class"])
    y_base = crop_response(crop, prior, args["sand_pct"], args["awc"], args["soc_gkg"], args["ndvi"], args["drainage_class"])
    gain = (y_with - y_base) * st["remaining"][None, :]

    return pd.DataFrame(
        {
            "biomass_gain": gain.mean(axis=0),
            "leach_risk": (lost > cfg.loss_threshold_kg).mean(axis=0),
            "n_lost_kg": lost.mean(axis=0),
            "drainage_mm": drain_total.mean(axis=0),
            "runoff_mm": runoff_total.mean(axis=0),
        }
    )


# --------------------------------------------------------------------------------------
# Surrogate model
# --------------------------------------------------------------------------------------
FEATURE_COLUMNS: tuple[str, ...] = (
    "sand_pct",
    "clay_pct",
    "soc_gkg",
    "awc",
    "theta_fc",
    "log_ksat",
    "drainage_class",
    "ndvi",
    "moisture_anomaly",
    "stage_code",
    "prior_n",
    "n_rate",
    "rain_d1",
    "rain_d2",
    "rain_d3",
    "rain_d4",
    "rain_d5",
    "rain_total",
    "rain_max",
    "irrigation_total",
    "et0_total",
)
# Monotone constraints: +1 increasing, -1 decreasing, 0 free.
GAIN_MONOTONE: dict[str, int] = {"n_rate": 1}
RISK_MONOTONE: dict[str, int] = {
    "n_rate": 1,
    "rain_d1": 1,
    "rain_d2": 1,
    "rain_d3": 1,
    "rain_d4": 1,
    "rain_d5": 1,
    "rain_total": 1,
    "rain_max": 1,
    "irrigation_total": 1,
    "et0_total": -1,
}


def build_features(inputs: pd.DataFrame, rain: FloatArray, et0: FloatArray, irrigation: FloatArray) -> pd.DataFrame:
    x = pd.DataFrame({c: inputs[c].to_numpy(dtype=np.float64) for c in SIM_INPUT_COLUMNS if c != "ksat_mm_h"})
    x["log_ksat"] = np.log10(np.maximum(inputs["ksat_mm_h"].to_numpy(dtype=np.float64), 1e-3))
    for i in range(FORECAST_DAYS):
        x[f"rain_d{i + 1}"] = rain[:, i]
    x["rain_total"] = rain.sum(axis=1)
    x["rain_max"] = rain.max(axis=1)
    x["irrigation_total"] = irrigation.sum(axis=1)
    x["et0_total"] = et0.sum(axis=1)
    return x[list(FEATURE_COLUMNS)]


@dataclass
class DualObjectiveRegressor:
    """Two monotone-constrained XGBoost heads sharing one feature space.

    sklearn's MultiOutputRegressor can't give each output its own constraints/objective,
    so the heads are held explicitly: squared error for biomass gain, logistic for risk
    (keeps predictions in [0, 1]).
    """

    crop: str
    n_estimators: int = 500
    max_depth: int = 6
    learning_rate: float = 0.05
    seed: int = 42
    gain_model: XGBRegressor | None = None
    risk_model: XGBRegressor | None = None
    metrics: dict[str, float] = field(default_factory=dict)

    def _constraints(self, mapping: dict[str, int]) -> str:
        return "(" + ",".join(str(mapping.get(c, 0)) for c in FEATURE_COLUMNS) + ")"

    def fit(self, x: pd.DataFrame, y: pd.DataFrame, x_val: pd.DataFrame | None = None, y_val: pd.DataFrame | None = None) -> DualObjectiveRegressor:
        common = dict(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            learning_rate=self.learning_rate,
            subsample=0.9,
            colsample_bytree=0.9,
            tree_method="hist",
            random_state=self.seed,
            n_jobs=-1,
        )
        self.gain_model = XGBRegressor(objective="reg:squarederror", monotone_constraints=self._constraints(GAIN_MONOTONE), **common)
        self.risk_model = XGBRegressor(objective="reg:logistic", monotone_constraints=self._constraints(RISK_MONOTONE), **common)
        self.gain_model.fit(x, y["biomass_gain"])
        self.risk_model.fit(x, y["leach_risk"])
        if x_val is not None and y_val is not None:
            pred = self.predict(x_val)
            self.metrics = {
                "gain_r2": round(float(r2_score(y_val["biomass_gain"], pred[:, 0])), 4),
                "gain_mae_kg_ha": round(float(mean_absolute_error(y_val["biomass_gain"], pred[:, 0])), 1),
                "risk_r2": round(float(r2_score(y_val["leach_risk"], pred[:, 1])), 4),
                "risk_mae": round(float(mean_absolute_error(y_val["leach_risk"], pred[:, 1])), 4),
                "n_val": float(len(x_val)),
            }
        return self

    def predict(self, x: pd.DataFrame) -> npt.NDArray[np.float64]:
        if self.gain_model is None or self.risk_model is None:
            raise RuntimeError("Model not fitted")
        gain = np.maximum(self.gain_model.predict(x[list(FEATURE_COLUMNS)]), 0.0)
        risk = np.clip(self.risk_model.predict(x[list(FEATURE_COLUMNS)]), 0.0, 1.0)
        return np.column_stack([gain, risk]).astype(np.float64)

    def save(self, out_dir: str | Path, crop_profile: CropProfile, sim_cfg: SimulatorConfig) -> Path:
        if self.gain_model is None or self.risk_model is None:
            raise RuntimeError("Model not fitted")
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        self.gain_model.save_model(out / "gain_head.json")
        self.risk_model.save_model(out / "risk_head.json")
        meta = {
            "crop": self.crop,
            "feature_columns": list(FEATURE_COLUMNS),
            "metrics": self.metrics,
            "crop_profile": asdict(crop_profile),
            "simulator_config": asdict(sim_cfg),
            "risk_limit": RISK_LIMIT,
        }
        (out / "model_meta.json").write_text(json.dumps(meta, indent=2))
        return out

    @classmethod
    def load(cls, model_dir: str | Path) -> tuple[DualObjectiveRegressor, CropProfile, SimulatorConfig]:
        d = Path(model_dir)
        meta = json.loads((d / "model_meta.json").read_text())
        if meta["feature_columns"] != list(FEATURE_COLUMNS):
            raise ValueError("Model feature schema does not match this code version; retrain.")
        model = cls(crop=meta["crop"], metrics=meta.get("metrics", {}))
        model.gain_model, model.risk_model = XGBRegressor(), XGBRegressor()
        model.gain_model.load_model(d / "gain_head.json")
        model.risk_model.load_model(d / "risk_head.json")
        cp = meta["crop_profile"]
        crop = CropProfile(**{**cp, "stages": tuple(StageProfile(**s) for s in cp["stages"])})
        return model, crop, SimulatorConfig(**meta["simulator_config"])


# --------------------------------------------------------------------------------------
# Training data generation
# --------------------------------------------------------------------------------------
def sample_scenarios(crop: CropProfile, n: int, rng: np.random.Generator) -> tuple[pd.DataFrame, FloatArray, FloatArray, FloatArray]:
    """Diverse soils x stages x forecasts x doses, spanning dry Mediterranean to storm-heavy humid weeks."""
    sand = rng.uniform(5.0, 92.0, n)
    clay = np.minimum(rng.uniform(3.0, 60.0, n), 100.0 - sand - 3.0).clip(2.0, None)
    soc = np.clip(rng.lognormal(math.log(11.0), 0.5, n), 2.0, 60.0)
    wp, fc, _, ksat = saxton_rawls(sand.astype(np.float32), clay.astype(np.float32), soc.astype(np.float32))
    awc = (fc - wp).astype(np.float64)
    ksat = ksat.astype(np.float64)
    base_dc = np.select([ksat >= 60, ksat >= 15, ksat >= 5, ksat >= 1.5], [0, 1, 2, 3], default=4).astype(np.float64)
    anomaly = rng.normal(0.0, 1.0, n)
    drainage = np.clip(base_dc + (anomaly > 1.0) + rng.normal(0, 0.3, n), 0.0, 4.0)
    stage_codes = rng.choice([s.code for s in crop.stages], n)
    prior = rng.choice([0.0, 0.0, 30.0, 60.0, 100.0, 150.0], n) * rng.uniform(0.8, 1.2, n)
    n_rate = np.where(rng.random(n) < 0.08, 0.0, rng.uniform(0.0, crop.max_n_rate_kg_ha, n))
    inputs = pd.DataFrame(
        {
            "sand_pct": sand,
            "clay_pct": clay,
            "soc_gkg": soc,
            "awc": awc,
            "theta_fc": fc.astype(np.float64),
            "ksat_mm_h": ksat,
            "drainage_class": drainage,
            "ndvi": rng.uniform(0.10, 0.92, n),
            "moisture_anomaly": anomaly,
            "stage_code": stage_codes.astype(np.float64),
            "prior_n": prior,
            "n_rate": n_rate,
        }
    )
    regime = rng.choice(3, n, p=[0.35, 0.45, 0.20])  # dry / showery / storm
    wet_prob = np.array([0.05, 0.40, 0.60])[regime][:, None]
    wet = rng.random((n, FORECAST_DAYS)) < wet_prob
    amount = rng.gamma(0.8, np.array([3.0, 8.0, 18.0])[regime][:, None], (n, FORECAST_DAYS))
    rain = wet * amount
    storm_day = rng.integers(0, FORECAST_DAYS, n)
    storm = (regime == 2) & (rng.random(n) < 0.7)
    rain[storm, storm_day[storm]] += rng.uniform(25.0, 90.0, storm.sum())
    et0 = rng.uniform(1.0, 7.5, (n, 1)) * rng.uniform(0.8, 1.2, (n, FORECAST_DAYS))
    irrigated = rng.random(n) < 0.35
    irr_days = rng.random((n, FORECAST_DAYS)) < 0.35
    irrigation = irrigated[:, None] * irr_days * rng.uniform(8.0, 35.0, (n, FORECAST_DAYS))
    return inputs, rain, et0, irrigation


def generate_training_set(crop: CropProfile, n: int, cfg: SimulatorConfig, seed: int = 0, batch: int = 4000) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    xs, ys = [], []
    for start in range(0, n, batch):
        m = min(batch, n - start)
        inputs, rain, et0, irr = sample_scenarios(crop, m, rng)
        labels = simulate(inputs, rain, et0, irr, crop, cfg, rng)
        xs.append(build_features(inputs, rain, et0, irr))
        ys.append(labels)
        LOGGER.info("simulated %d / %d", start + m, n)
    return pd.concat(xs, ignore_index=True), pd.concat(ys, ignore_index=True)


def train_model(crop: CropProfile, n_samples: int = 40_000, cfg: SimulatorConfig = SimulatorConfig(), seed: int = 0) -> DualObjectiveRegressor:
    x, y = generate_training_set(crop, n_samples, cfg, seed)
    rng = np.random.default_rng(seed + 1)
    idx = rng.permutation(len(x))
    cut = int(0.85 * len(x))
    tr, va = idx[:cut], idx[cut:]
    model = DualObjectiveRegressor(crop=crop.name, seed=seed)
    model.fit(x.iloc[tr], y.iloc[tr], x.iloc[va], y.iloc[va])
    LOGGER.info("validation metrics: %s", model.metrics)
    return model


# --------------------------------------------------------------------------------------
# Optimisation
# --------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ZoneRecommendation:
    zone_id: int
    zone_name: str
    zone_type: str
    area_ha: float
    n_opt_kg_ha: float
    n_unconstrained_kg_ha: float
    biomass_gain_kg_ha: float
    leach_risk: float
    sim_biomass_gain_kg_ha: float
    sim_leach_risk: float
    sim_n_lost_kg_ha: float
    binding_constraint: bool
    advisory: str

    @property
    def n_opt_lb_ac(self) -> float:
        return self.n_opt_kg_ha * KG_HA_TO_LB_AC


def _zone_inputs(zone: ZoneConditions, stage: StageProfile, prior_n: float, n_grid: FloatArray) -> pd.DataFrame:
    k = len(n_grid)
    return pd.DataFrame(
        {
            "sand_pct": np.full(k, zone.sand_pct),
            "clay_pct": np.full(k, zone.clay_pct),
            "soc_gkg": np.full(k, zone.soc_gkg),
            "awc": np.full(k, zone.awc),
            "theta_fc": np.full(k, zone.theta_fc),
            "ksat_mm_h": np.full(k, zone.ksat_mm_h),
            "drainage_class": np.full(k, zone.drainage_class),
            "ndvi": np.full(k, zone.ndvi),
            "moisture_anomaly": np.full(k, zone.moisture_anomaly),
            "stage_code": np.full(k, float(stage.code)),
            "prior_n": np.full(k, prior_n),
            "n_rate": n_grid,
        }
    )


def recommend_zone(
    zone: ZoneConditions,
    model: DualObjectiveRegressor,
    crop: CropProfile,
    stage_name: str,
    weather: WeatherWindow,
    prior_n: float = 0.0,
    risk_limit: float = RISK_LIMIT,
    step_kg: float = 5.0,
    plateau_tolerance: float = 0.01,
    objective: Literal["yield", "profit"] = "yield",
    grain_price_per_kg: float = 0.18,
    n_price_per_kg: float = 1.10,
    sim_cfg: SimulatorConfig = SimulatorConfig(),
) -> ZoneRecommendation:
    """Grid-search N on the surrogate, then verify (and if needed step down) with the simulator."""
    stage = crop.stage(stage_name)
    grid = np.arange(0.0, crop.max_n_rate_kg_ha + 1e-9, step_kg)
    inputs = _zone_inputs(zone, stage, prior_n, grid)
    k = len(grid)
    rain = np.tile(np.array(weather.precip_mm), (k, 1))
    et0 = np.tile(np.array(weather.et0_mm), (k, 1))
    irr = np.tile(np.array(weather.irrigation_mm), (k, 1))
    pred = model.predict(build_features(inputs, rain, et0, irr))
    gain, risk = pred[:, 0], pred[:, 1]

    def choose(feasible: npt.NDArray[np.bool_]) -> int:
        if objective == "profit":
            value = gain * crop.harvest_index * grain_price_per_kg - grid * n_price_per_kg
            value = np.where(feasible, value, -np.inf)
            return int(np.argmax(value))
        best = float(np.max(np.where(feasible, gain, -np.inf)))
        ok = feasible & (gain >= best - plateau_tolerance * max(best, 1.0))
        return int(np.argmax(ok))  # smallest rate on the feasible plateau

    i_unc = choose(np.ones(k, dtype=bool))
    i_opt = choose(risk < risk_limit)

    # Verify with the full simulator (more draws); step down until the simulator agrees.
    verify_cfg = replace(sim_cfg, n_draws=max(sim_cfg.n_draws, 512))
    sim = simulate(inputs.iloc[[i_opt]], rain[[i_opt]], et0[[i_opt]], irr[[i_opt]], crop, verify_cfg, np.random.default_rng(verify_cfg.seed))
    while i_opt > 0 and float(sim["leach_risk"].iloc[0]) >= risk_limit:
        i_opt -= 1
        sim = simulate(inputs.iloc[[i_opt]], rain[[i_opt]], et0[[i_opt]], irr[[i_opt]], crop, verify_cfg, np.random.default_rng(verify_cfg.seed))

    n_opt, n_unc = float(grid[i_opt]), float(grid[i_unc])
    binding = n_opt < n_unc - 1e-9
    advisory = _advisory(zone, stage, weather, n_opt, n_unc, float(sim["runoff_mm"].iloc[0]), crop)
    return ZoneRecommendation(
        zone_id=zone.zone_id,
        zone_name=zone.zone_name,
        zone_type=zone.zone_type,
        area_ha=zone.area_ha,
        n_opt_kg_ha=n_opt,
        n_unconstrained_kg_ha=n_unc,
        biomass_gain_kg_ha=round(float(gain[i_opt]), 1),
        leach_risk=round(float(risk[i_opt]), 4),
        sim_biomass_gain_kg_ha=round(float(sim["biomass_gain"].iloc[0]), 1),
        sim_leach_risk=round(float(sim["leach_risk"].iloc[0]), 4),
        sim_n_lost_kg_ha=round(float(sim["n_lost_kg"].iloc[0]), 2),
        binding_constraint=binding,
        advisory=advisory,
    )


def _advisory(zone: ZoneConditions, stage: StageProfile, weather: WeatherWindow, n_opt: float, n_unc: float, runoff_mm: float, crop: CropProfile) -> str:
    notes: list[str] = []
    rain = np.array(weather.precip_mm) + np.array(weather.irrigation_mm)
    if n_unc > 0 and n_opt < 0.7 * n_unc:
        wettest = int(np.argmax(rain))
        after = weather.dates[wettest] if wettest < len(weather.dates) else f"day {wettest + 1}"
        notes.append(
            f"Split application: {n_opt:.0f} kg/ha now, remaining {n_unc - n_opt:.0f} kg/ha after the "
            f"{rain[wettest]:.0f} mm event ({after}) once the risk re-evaluates below {RISK_LIMIT:.2f}."
        )
    if sum(weather.irrigation_mm) > 0 and zone.awc * stage.root_depth_mm < sum(weather.irrigation_mm) * 0.8:
        notes.append("Planned irrigation exceeds root-zone storage; shorten sets to cut drainage.")
    if zone.zone_type == "Saturated Lowland":
        notes.append("Wet zone: denitrification/runoff losses likely; avoid surface-applied urea before rain.")
    if zone.zone_type == "High-Leaching Sand":
        notes.append("Coarse zone: prefer smaller, more frequent doses (fertigation or sidedress).")
    if runoff_mm > 5.0:
        notes.append(f"~{runoff_mm:.0f} mm runoff expected; incorporate or inject N.")
    if crop.provisional:
        notes.append("Crop profile is provisional; confirm with a soil nitrate quick test.")
    if stage.remaining_demand_frac < 0.3 and n_opt > 0:
        notes.append("Late stage: limited yield benefit from additional N.")
    return " ".join(notes) if notes else "No constraints binding."


def build_prescription(
    zones: Sequence[ZoneConditions],
    model: DualObjectiveRegressor,
    crop: CropProfile,
    stage_name: str,
    weather: WeatherWindow,
    prior_n: float = 0.0,
    product_n_fraction: float = 0.32,
    product_name: str = "UAN-32",
    **kwargs: Any,
) -> pd.DataFrame:
    """Per-zone prescription table (the input to Phase 4 map export)."""
    rows: list[dict[str, Any]] = []
    for zone in zones:
        rec = recommend_zone(zone, model, crop, stage_name, weather, prior_n, **kwargs)
        product_kg = rec.n_opt_kg_ha / product_n_fraction
        rows.append(
            {
                "zone_id": rec.zone_id,
                "zone_name": rec.zone_name,
                "zone_type": rec.zone_type,
                "area_ha": rec.area_ha,
                "n_rate_kg_ha": rec.n_opt_kg_ha,
                "n_rate_lb_ac": round(rec.n_opt_lb_ac, 1),
                "product": product_name,
                "product_kg_ha": round(product_kg, 1),
                "product_lb_ac": round(product_kg * KG_HA_TO_LB_AC, 1),
                "n_unconstrained_kg_ha": rec.n_unconstrained_kg_ha,
                "biomass_gain_kg_ha": rec.biomass_gain_kg_ha,
                "leach_risk": rec.leach_risk,
                "sim_leach_risk": rec.sim_leach_risk,
                "sim_n_lost_kg_ha": rec.sim_n_lost_kg_ha,
                "binding_constraint": rec.binding_constraint,
                "zone_n_total_kg": round(rec.n_opt_kg_ha * rec.area_ha, 1),
                "advisory": rec.advisory,
            }
        )
    rx = pd.DataFrame(rows)
    rx.attrs.update(
        {
            "crop": crop.name,
            "stage": stage_name,
            "weather_source": weather.source,
            "forecast_dates": list(weather.dates),
            "risk_limit": RISK_LIMIT,
        }
    )
    return rx


def uniform_rate_comparison(rx: pd.DataFrame, zones: Sequence[ZoneConditions], crop: CropProfile, stage_name: str, weather: WeatherWindow, prior_n: float, sim_cfg: SimulatorConfig) -> dict[str, float]:
    """Compare the variable-rate plan with a flat rate equal to the unconstrained field-average N."""
    area = rx["area_ha"].to_numpy()
    flat = float(np.average(rx["n_unconstrained_kg_ha"], weights=area))
    stage = crop.stage(stage_name)
    totals = {"vr": [0.0, 0.0, 0.0], "flat": [0.0, 0.0, 0.0]}  # N applied, N lost, biomass gain (field totals)
    for zone, (_, r) in zip(zones, rx.iterrows()):
        for key, rate in (("vr", float(r["n_rate_kg_ha"])), ("flat", flat)):
            inp = _zone_inputs(zone, stage, prior_n, np.array([rate]))
            s = simulate(
                inp,
                np.array([weather.precip_mm]),
                np.array([weather.et0_mm]),
                np.array([weather.irrigation_mm]),
                crop,
                replace(sim_cfg, n_draws=512),
                np.random.default_rng(sim_cfg.seed),
            )
            totals[key][0] += rate * zone.area_ha
            totals[key][1] += float(s["n_lost_kg"].iloc[0]) * zone.area_ha
            totals[key][2] += float(s["biomass_gain"].iloc[0]) * zone.area_ha
    return {
        "flat_rate_kg_ha": round(flat, 1),
        "n_applied_vr_kg": round(totals["vr"][0], 0),
        "n_applied_flat_kg": round(totals["flat"][0], 0),
        "n_lost_vr_kg": round(totals["vr"][1], 1),
        "n_lost_flat_kg": round(totals["flat"][1], 1),
        "biomass_gain_vr_t": round(totals["vr"][2] / 1000.0, 1),
        "biomass_gain_flat_t": round(totals["flat"][2] / 1000.0, 1),
    }


# --------------------------------------------------------------------------------------
# Calibration on real N-rate trials (e.g. PRNT, Ransom et al. 2021)
# --------------------------------------------------------------------------------------
def quadratic_plateau(n: FloatArray, a: float, b: float, c: float) -> FloatArray:
    join = -b / (2.0 * c)
    n_eff = np.minimum(n, join)
    return a + b * n_eff + c * n_eff**2


def fit_quadratic_plateau(n_rate: FloatArray, yld: FloatArray) -> dict[str, float] | None:
    if len(np.unique(n_rate)) < 4:
        return None
    a0 = float(np.median(yld[n_rate == n_rate.min()]))
    top = float(np.percentile(yld, 90))
    try:
        popt, _ = curve_fit(
            quadratic_plateau,
            n_rate,
            yld,
            p0=[a0, 2.0 * (top - a0) / 180.0, -(top - a0) / 180.0**2],
            bounds=([0.0, 1e-6, -10.0], [np.inf, np.inf, -1e-9]),
            maxfev=20_000,
        )
    except (RuntimeError, ValueError):
        return None
    a, b, c = (float(v) for v in popt)
    join = -b / (2.0 * c)
    plateau = a + b * join + c * join**2
    if not (0 < join < 500 and plateau > a):
        return None
    return {"intercept": a, "join_n": join, "plateau": plateau, "rel_yield_0n": a / plateau}


def calibrate_crop_profile(
    trials: pd.DataFrame,
    site_col: str,
    n_col: str,
    yield_col: str,
    base: CropProfile,
    yield_units: Literal["kg_ha", "bu_ac", "t_ha"] = "kg_ha",
    n_units: Literal["kg_ha", "lb_ac"] = "kg_ha",
) -> tuple[CropProfile, pd.DataFrame]:
    """Fit a quadratic-plateau per site-year; set crop defaults to the across-site medians."""
    df = trials[[site_col, n_col, yield_col]].dropna().copy()
    ymul = {"kg_ha": 1.0, "bu_ac": BU_AC_CORN_TO_KG_HA, "t_ha": 1000.0}[yield_units]
    nmul = 1.0 if n_units == "kg_ha" else 1.0 / KG_HA_TO_LB_AC
    df["y"] = df[yield_col].astype(float) * ymul
    df["n"] = df[n_col].astype(float) * nmul
    fits: list[dict[str, Any]] = []
    for site, g in df.groupby(site_col):
        res = fit_quadratic_plateau(g["n"].to_numpy(), g["y"].to_numpy())
        if res:
            fits.append({"site": site, **res})
    if len(fits) < 3:
        raise ValueError(f"Only {len(fits)} site-years produced valid fits; check column mapping/units.")
    fit_df = pd.DataFrame(fits)
    calibrated = replace(
        base,
        ymax_biomass_kg_ha=float(fit_df["plateau"].median()) / base.harvest_index,
        soil_supply_frac=float(np.clip(fit_df["rel_yield_0n"].median(), 0.3, 0.85)),
        n_crit_kg_ha=float(fit_df["join_n"].median()),
        source=f"Calibrated on {len(fit_df)} site-year QP fits",
        provisional=False,
    )
    return calibrated, fit_df


# --------------------------------------------------------------------------------------
# Self-test & CLI
# --------------------------------------------------------------------------------------
def _demo_zone(zone_type: str, sand: float, clay: float, soc: float, anomaly: float, ndvi: float, zone_id: int) -> ZoneConditions:
    wp, fc, _, ks = saxton_rawls(np.array([sand], np.float32), np.array([clay], np.float32), np.array([soc], np.float32))
    ksat = float(ks[0])
    dc = float(np.select([ksat >= 60, ksat >= 15, ksat >= 5, ksat >= 1.5], [0, 1, 2, 3], default=4)) + (1.0 if anomaly > 1.0 else 0.0)
    return ZoneConditions(zone_id, zone_type, zone_type, 20.0, sand, clay, soc, float(fc[0] - wp[0]), ksat, min(dc, 4.0), ndvi, anomaly)


def run_self_test(n_samples: int = 12_000) -> dict[str, Any]:
    crop = CROPS["corn"]
    cfg = SimulatorConfig()
    sand_zone = _demo_zone("High-Leaching Sand", 82.0, 6.0, 5.0, -0.3, 0.45, 1)
    loam_zone = _demo_zone("High-Retention Loam", 35.0, 25.0, 15.0, 0.0, 0.62, 2)
    wet_zone = _demo_zone("Saturated Lowland", 20.0, 38.0, 20.0, 1.6, 0.55, 3)
    stage = crop.stage("V4-V6")

    def sim_one(zone: ZoneConditions, rate: float, rain: Sequence[float]) -> pd.Series:
        out = simulate(
            _zone_inputs(zone, stage, 0.0, np.array([rate])),
            np.array([rain], dtype=float),
            np.full((1, 5), 4.0),
            np.zeros((1, 5)),
            crop,
            replace(cfg, n_draws=1000),
        )
        return out.iloc[0]

    storm = [0, 5, 45, 20, 0]
    dry = [0, 0, 0, 0, 0]
    assert sim_one(sand_zone, 0.0, storm)["leach_risk"] == 0.0
    assert sim_one(sand_zone, 150, storm)["leach_risk"] > sim_one(sand_zone, 150, dry)["leach_risk"]
    assert sim_one(sand_zone, 150, storm)["leach_risk"] > sim_one(loam_zone, 150, storm)["leach_risk"]
    assert sim_one(sand_zone, 150, storm)["leach_risk"] >= sim_one(sand_zone, 60, storm)["leach_risk"]
    assert sim_one(loam_zone, 150, dry)["biomass_gain"] > sim_one(loam_zone, 50, dry)["biomass_gain"] > 0

    model = train_model(crop, n_samples, cfg, seed=3)
    assert model.metrics["gain_r2"] > 0.9, model.metrics
    assert model.metrics["risk_r2"] > 0.8, model.metrics

    zones = [sand_zone, loam_zone, wet_zone]
    dry_w = manual_weather(dry, [5.0] * 5)
    storm_w = manual_weather(storm, [3.0] * 5)
    rx_dry = build_prescription(zones, model, crop, "V4-V6", dry_w)
    rx_storm = build_prescription(zones, model, crop, "V4-V6", storm_w)
    assert (rx_storm["sim_leach_risk"] < RISK_LIMIT).all(), rx_storm
    assert rx_storm.loc[0, "n_rate_kg_ha"] < rx_dry.loc[0, "n_rate_kg_ha"], (rx_storm, rx_dry)
    return {
        "surrogate_metrics": model.metrics,
        "dry_week_rates": dict(zip(rx_dry["zone_name"], rx_dry["n_rate_kg_ha"])),
        "storm_week_rates": dict(zip(rx_storm["zone_name"], rx_storm["n_rate_kg_ha"])),
        "storm_week_sim_risk": dict(zip(rx_storm["zone_name"], rx_storm["sim_leach_risk"])),
        "status": "ok",
    }


def _field_centroid(geojson_path: Path) -> tuple[float, float]:
    import geopandas as gpd

    gdf = gpd.read_file(geojson_path).to_crs("EPSG:4326")
    projected = gdf.to_crs(gdf.estimate_utm_crs())
    c = projected.geometry.union_all().centroid
    lon, lat = gpd.GeoSeries([c], crs=projected.crs).to_crs("EPSG:4326").iloc[0].coords[0]
    return float(lat), float(lon)


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Dual-objective nitrogen recommender (Phase 3)")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("selftest")

    tr = sub.add_parser("train")
    tr.add_argument("--crop", choices=list(CROPS), default="corn")
    tr.add_argument("--samples", type=int, default=40_000)
    tr.add_argument("--calibrated-profile", type=Path, default=None, help="JSON from `calibrate`")
    tr.add_argument("--seed", type=int, default=0)
    tr.add_argument("--out", type=Path, required=True)

    rc = sub.add_parser("recommend")
    rc.add_argument("--model", type=Path, required=True)
    rc.add_argument("--zones", type=Path, required=True, help="Phase 2 zone_profile.csv")
    rc.add_argument("--stage", required=True)
    rc.add_argument("--prior-n", type=float, default=0.0, help="N already applied this season (kg/ha)")
    rc.add_argument("--lat", type=float, default=None)
    rc.add_argument("--lon", type=float, default=None)
    rc.add_argument("--zones-geojson", type=Path, default=None, help="Phase 2 zones.geojson (for field centroid)")
    rc.add_argument("--rain", type=float, nargs=5, default=None, help="Override forecast precip (mm/day x5)")
    rc.add_argument("--et0", type=float, nargs=5, default=None)
    rc.add_argument("--irrigation", type=float, nargs=5, default=None, help="Planned irrigation (mm/day x5)")
    rc.add_argument("--objective", choices=["yield", "profit"], default="yield")
    rc.add_argument("--product", default="UAN-32")
    rc.add_argument("--product-n-fraction", type=float, default=0.32)
    rc.add_argument("--out", type=Path, required=True)

    cal = sub.add_parser("calibrate")
    cal.add_argument("--trials", type=Path, required=True)
    cal.add_argument("--site-col", required=True)
    cal.add_argument("--n-col", required=True)
    cal.add_argument("--yield-col", required=True)
    cal.add_argument("--yield-units", choices=["kg_ha", "bu_ac", "t_ha"], default="kg_ha")
    cal.add_argument("--n-units", choices=["kg_ha", "lb_ac"], default="kg_ha")
    cal.add_argument("--crop", choices=list(CROPS), default="corn")
    cal.add_argument("--out", type=Path, required=True, help="Output JSON crop profile")
    return p


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, format="%(levelname)s %(message)s")

    if args.command == "selftest":
        print(json.dumps(run_self_test(), indent=2))
        return 0

    if args.command == "calibrate":
        trials = pd.read_csv(args.trials)
        profile, fits = calibrate_crop_profile(
            trials, args.site_col, args.n_col, args.yield_col, CROPS[args.crop], args.yield_units, args.n_units
        )
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(asdict(profile), indent=2))
        fits.to_csv(args.out.with_suffix(".fits.csv"), index=False)
        print(json.dumps({"profile": asdict(profile), "n_site_years": len(fits)}, indent=2, default=str))
        return 0

    if args.command == "train":
        crop = CROPS[args.crop]
        if args.calibrated_profile:
            cp = json.loads(args.calibrated_profile.read_text())
            crop = CropProfile(**{**cp, "stages": tuple(StageProfile(**s) for s in cp["stages"])})
        cfg = SimulatorConfig()
        model = train_model(crop, args.samples, cfg, args.seed)
        model.save(args.out, crop, cfg)
        print(json.dumps({"model_dir": str(args.out), "metrics": model.metrics}, indent=2))
        return 0

    # recommend
    model, crop, cfg = DualObjectiveRegressor.load(args.model)
    zones = load_zone_profile(args.zones)
    if args.rain is not None:
        weather = manual_weather(args.rain, args.et0, args.irrigation)
    else:
        lat, lon = args.lat, args.lon
        if (lat is None or lon is None) and args.zones_geojson is not None:
            lat, lon = _field_centroid(args.zones_geojson)
        if lat is None or lon is None:
            raise SystemExit("Provide --lat/--lon, --zones-geojson, or --rain for an offline forecast.")
        weather = fetch_open_meteo_forecast(lat, lon)
        if args.et0 is not None or args.irrigation is not None:
            weather = replace(
                weather,
                et0_mm=tuple(args.et0) if args.et0 else weather.et0_mm,
                irrigation_mm=tuple(args.irrigation) if args.irrigation else weather.irrigation_mm,
            )
    rx = build_prescription(
        zones,
        model,
        crop,
        args.stage,
        weather,
        args.prior_n,
        product_n_fraction=args.product_n_fraction,
        product_name=args.product,
        objective=args.objective,
        sim_cfg=cfg,
    )
    args.out.parent.mkdir(parents=True, exist_ok=True)
    rx.to_csv(args.out, index=False)
    comparison = uniform_rate_comparison(rx, zones, crop, args.stage, weather, args.prior_n, cfg)
    summary = {
        "crop": crop.name,
        "stage": args.stage,
        "weather": asdict(weather),
        "model_metrics": model.metrics,
        "prescription": json.loads(rx.drop(columns=["advisory"]).to_json(orient="records")),
        "advisories": dict(zip(rx["zone_name"], rx["advisory"])),
        "vs_flat_rate": comparison,
    }
    args.out.with_suffix(".json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
