# Precision Nitrogen & Soil Runoff Advisor

Zone-level nitrogen prescriptions for agricultural co-ops, built from open satellite, soil and weather data.
Rates maximise crop response while keeping forecast leaching/runoff risk below 0.15.

| Phase | File | What it does | Open data |
|---|---|---|---|
| 1 | `spectral_engine.py` | Sentinel-2 L2A ingest, SCL cloud mask, NDVI / NDWI / SAVI, synthetic S2 generator | Element 84 Earth Search (AWS Open Data) |
| 2 | `clustering.py` | Soil hydraulics (Saxton & Rawls 2006), K-Means zones (k=3–5, silhouette), zone labels | ISRIC SoilGrids 2.0 (CC-BY 4.0) |
| 3 | `nitrogen_model.py` | Process simulator + monotone XGBoost dual-output surrogate, constrained N optimiser | Open-Meteo forecast; PRNT N-rate trials for calibration |
| 4 | `app.py` | Streamlit + Folium portal: draw field, run, view zones, export Shapefile / CSV | — |

## Quick start
```bash
pip install -r requirements.txt
python spectral_engine.py selftest && python clustering.py selftest && python nitrogen_model.py selftest
streamlit run app.py          # "Synthetic demo" works offline; first run trains the N model (~1–2 min)
```

## Command line (no UI)
```bash
python clustering.py real --bbox -121.535 36.560 -121.515 36.575 --start 2025-06-01 --end 2025-07-31 \
    --out out/field1 --cache cache/soilgrids
python nitrogen_model.py train --crop corn --out models/corn
python nitrogen_model.py recommend --model models/corn --zones out/field1/zone_profile.csv \
    --zones-geojson out/field1/zones.geojson --stage V8-V10 --prior-n 40 --out out/field1/rx.csv
```

## Calibrating crop response on real trials
Download the PRNT corn N-rate dataset (Ransom et al. 2021, Dryad doi:10.5061/dryad.66t1g1k2g), then:
```bash
python nitrogen_model.py calibrate --trials prnt.csv --site-col <SITE-YEAR COL> --n-col <N RATE COL> \
    --yield-col <YIELD COL> --yield-units kg_ha --out profiles/corn_prnt.json
python nitrogen_model.py train --crop corn --calibrated-profile profiles/corn_prnt.json --out models/corn
```
Delete `models/<crop>` to force the app to retrain.

## Outputs
- `*_shp.zip` — zone polygons (EPSG:4326) with `N_KG_HA`, `N_LB_AC`, `PROD_LB_AC`, `RISK` for rate controllers / FMIS import
- `*_grid.csv` — 20 m point grid (lat, lon, rates)
- `*_zones.csv`, `*_report.json` — zone table and full audit trail (inputs, scene ID, forecast, warnings)

Advisory tool: verify with local agronomic guidance and in-season soil/tissue tests; follow label and regulatory limits.
