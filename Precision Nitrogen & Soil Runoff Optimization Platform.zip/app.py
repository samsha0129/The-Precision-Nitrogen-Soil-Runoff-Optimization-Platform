"""
app.py — Phase 4: Geospatial Advisor Portal for the Precision Nitrogen & Soil Runoff
Optimization Platform.

    streamlit run app.py

Workflow
--------
1. Draw a field boundary on the satellite map (or upload GeoJSON / zipped Shapefile).
2. Choose crop, growth stage, N already applied, irrigation plan and forecast source.
3. Run: Phase 1 (Sentinel-2 indices) -> Phase 2 (SoilGrids + K-Means zones) ->
   Phase 3 (dual-objective N rate per zone under the 5-day forecast).
4. Review colour-coded zones, the variable-rate map, risk and advisories.
5. Download the prescription as a zipped Shapefile (zone polygons + rate attributes,
   importable by common rate controllers / farm-management software), a point-grid CSV,
   a zone-level CSV and a JSON audit report.

"Synthetic demo" mode runs fully offline; "Live data" mode pulls Sentinel-2 L2A (Earth
Search), SoilGrids 2.0 (ISRIC) and the Open-Meteo forecast.
"""

from __future__ import annotations

import io
import json
import logging
import tempfile
import zipfile
from dataclasses import asdict, dataclass, field
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Literal

import branca.colormap as bcm
import folium
import geopandas as gpd
import numpy as np
import numpy.typing as npt
import pandas as pd
from folium.plugins import Draw, Fullscreen
from rasterio.transform import array_bounds
from rasterio.enums import Resampling
from rasterio.warp import calculate_default_transform, reproject
from shapely.geometry import Polygon, mapping, shape
from shapely.geometry.base import BaseGeometry

from clustering import ZoningResult, fetch_soilgrids, run_zoning, synthetic_soil_layers
from nitrogen_model import (
    CROPS,
    FORECAST_DAYS,
    KG_HA_TO_LB_AC,
    RISK_LIMIT,
    CropProfile,
    DualObjectiveRegressor,
    SimulatorConfig,
    WeatherWindow,
    build_prescription,
    fetch_open_meteo_forecast,
    manual_weather,
    train_model,
    uniform_rate_comparison,
    zones_from_dataframe,
)
from spectral_engine import (
    SpectralTile,
    SyntheticFieldConfig,
    apply_boundary_mask,
    compute_indices,
    fetch_sentinel2_tile,
    synthetic_tile,
)

LOGGER = logging.getLogger("app")
MODELS_DIR = Path(__file__).resolve().parent / "models"
SOIL_CACHE_DIR = Path(__file__).resolve().parent / "cache" / "soilgrids"
DEFAULT_CENTER = (36.568, -121.525)  # Salinas Valley floor near Chualar, CA
ESRI_IMAGERY = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
MAX_FIELD_HA = 1_500.0
MIN_FIELD_HA = 2.0

DataMode = Literal["synthetic", "live"]


# ======================================================================================
# Pure pipeline & export logic (importable and testable without Streamlit)
# ======================================================================================
@dataclass
class RunSettings:
    mode: DataMode
    crop_name: str
    stage: str
    prior_n: float
    objective: Literal["yield", "profit"] = "yield"
    product_name: str = "UAN-32"
    product_n_fraction: float = 0.32
    k_min: int = 3
    k_max: int = 5
    min_zone_ha: float = 0.5
    imagery_start: str = ""
    imagery_end: str = ""
    max_cloud: float = 30.0
    synthetic_stage: str = "vegetative"
    synthetic_seed: int = 42
    use_forecast: bool = True
    manual_rain: tuple[float, ...] = (0.0,) * FORECAST_DAYS
    manual_et0: tuple[float, ...] = (4.0,) * FORECAST_DAYS
    irrigation: tuple[float, ...] = (0.0,) * FORECAST_DAYS


@dataclass
class FieldRun:
    settings: RunSettings
    boundary: BaseGeometry
    tile: SpectralTile
    zoning: ZoningResult
    rx: pd.DataFrame
    weather: WeatherWindow
    comparison: dict[str, float]
    soil_source: str
    warnings: list[str] = field(default_factory=list)


def geodesic_area_ha(geom: BaseGeometry) -> float:
    gs = gpd.GeoSeries([geom], crs="EPSG:4326")
    return float(gs.to_crs(gs.estimate_utm_crs()).area.iloc[0] / 10_000.0)


def default_demo_boundary(tile: SpectralTile) -> Polygon:
    """An irregular field polygon inset within the synthetic tile."""
    w, s, e, n = tile.bounds_wgs84
    dx, dy = e - w, n - s
    pts = [(0.08, 0.10), (0.90, 0.06), (0.94, 0.55), (0.78, 0.93), (0.20, 0.90), (0.05, 0.50)]
    return Polygon([(w + fx * dx, s + fy * dy) for fx, fy in pts])


def read_uploaded_boundary(name: str, data: bytes) -> BaseGeometry:
    """Parse a GeoJSON or zipped Shapefile upload into a single EPSG:4326 (multi)polygon."""
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / name
        path.write_bytes(data)
        uri = f"zip://{path}" if name.lower().endswith(".zip") else str(path)
        gdf = gpd.read_file(uri)
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326")
    gdf = gdf.to_crs("EPSG:4326")
    geom = gdf.geometry.union_all()
    if geom.is_empty or geom.geom_type not in ("Polygon", "MultiPolygon"):
        raise ValueError("Boundary file must contain polygon geometry.")
    return geom.buffer(0)


def resolve_weather(settings: RunSettings, lat: float, lon: float) -> tuple[WeatherWindow, list[str]]:
    warnings: list[str] = []
    if settings.use_forecast:
        try:
            wx = fetch_open_meteo_forecast(lat, lon)
            return WeatherWindow(wx.dates, wx.precip_mm, wx.et0_mm, tuple(settings.irrigation), wx.source), warnings
        except Exception as exc:  # network errors, API changes
            warnings.append(f"Open-Meteo forecast unavailable ({exc}); used the manual what-if values instead.")
    return manual_weather(settings.manual_rain, settings.manual_et0, settings.irrigation), warnings


def run_pipeline(
    settings: RunSettings,
    boundary: BaseGeometry | None,
    model: DualObjectiveRegressor,
    crop: CropProfile,
    sim_cfg: SimulatorConfig,
) -> FieldRun:
    """Phase 1 -> Phase 2 -> Phase 3 for one field."""
    warnings: list[str] = []
    if settings.mode == "synthetic":
        cfg = SyntheticFieldConfig(crop_stage=settings.synthetic_stage, seed=settings.synthetic_seed, cloud_fraction=0.05)  # type: ignore[arg-type]
        tile, scene = synthetic_tile(cfg)
        tile_poly = Polygon.from_bounds(*tile.bounds_wgs84)
        if boundary is None or not boundary.intersects(tile_poly) or boundary.intersection(tile_poly).area < 0.2 * boundary.area:
            if boundary is not None:
                warnings.append("Synthetic mode only covers the demo tile near Chualar, CA; used the demo field boundary.")
            boundary = default_demo_boundary(tile)
        soil_full = synthetic_soil_layers(scene, tile, seed=settings.synthetic_seed)
        tile = apply_boundary_mask(tile, boundary)
        soil = soil_full
    else:
        if boundary is None:
            raise ValueError("Draw or upload a field boundary first.")
        area = geodesic_area_ha(boundary)
        if not MIN_FIELD_HA <= area <= MAX_FIELD_HA:
            raise ValueError(f"Field is {area:.1f} ha; supported range is {MIN_FIELD_HA}-{MAX_FIELD_HA} ha.")
        minx, miny, maxx, maxy = boundary.buffer(0.0008).bounds
        tile = fetch_sentinel2_tile((minx, miny, maxx, maxy), settings.imagery_start, settings.imagery_end, settings.max_cloud)
        tile = apply_boundary_mask(tile, boundary)
        if tile.valid_fraction < 0.05:
            raise ValueError("Almost no cloud-free pixels inside the boundary; widen the imagery date window.")
        soil = fetch_soilgrids(tile, SOIL_CACHE_DIR)

    zoning = run_zoning(tile, soil, k_range=(settings.k_min, settings.k_max), min_zone_ha=settings.min_zone_ha)
    centroid = boundary.centroid
    weather, wx_warn = resolve_weather(settings, centroid.y, centroid.x)
    warnings.extend(wx_warn)
    zones = zones_from_dataframe(zoning.profile)
    rx = build_prescription(
        zones,
        model,
        crop,
        settings.stage,
        weather,
        settings.prior_n,
        product_n_fraction=settings.product_n_fraction,
        product_name=settings.product_name,
        objective=settings.objective,
        sim_cfg=sim_cfg,
    )
    comparison = uniform_rate_comparison(rx, zones, crop, settings.stage, weather, settings.prior_n, sim_cfg)
    if crop.provisional:
        warnings.append(f"The {crop.name} crop profile is provisional — validate rates locally before use.")
    return FieldRun(settings, boundary, tile, zoning, rx, weather, comparison, soil.source, warnings)


def prescription_polygons(run: FieldRun) -> gpd.GeoDataFrame:
    """Zone polygons (EPSG:4326) carrying the prescribed rates."""
    cols = ["zone_id", "zone_name", "zone_type", "n_rate_kg_ha", "n_rate_lb_ac", "product", "product_kg_ha", "product_lb_ac", "leach_risk", "sim_leach_risk", "advisory"]
    poly = run.zoning.polygons[["zone_id", "area_ha", "color", "geometry"]].merge(run.rx[cols], on="zone_id", how="left")
    return poly.to_crs("EPSG:4326")


def shapefile_zip_bytes(run: FieldRun) -> bytes:
    """Zipped ESRI Shapefile with 10-char-safe field names for rate controllers."""
    gdf = prescription_polygons(run)
    out = gpd.GeoDataFrame(
        {
            "ZONE_ID": gdf["zone_id"].astype(int),
            "ZONE_NAME": gdf["zone_name"].str.slice(0, 80),
            "AREA_HA": gdf["area_ha"].round(2),
            "N_KG_HA": gdf["n_rate_kg_ha"].round(1),
            "N_LB_AC": gdf["n_rate_lb_ac"].round(1),
            "PRODUCT": gdf["product"],
            "PROD_KG_HA": gdf["product_kg_ha"].round(1),
            "PROD_LB_AC": gdf["product_lb_ac"].round(1),
            "RISK": gdf["sim_leach_risk"].round(3),
        },
        geometry=gdf.geometry.buffer(0),
        crs="EPSG:4326",
    )
    buf = io.BytesIO()
    with tempfile.TemporaryDirectory() as tmp:
        shp = Path(tmp) / "n_prescription.shp"
        out.to_file(shp, driver="ESRI Shapefile", encoding="utf-8")
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(Path(tmp).iterdir()):
                zf.write(f, arcname=f.name)
    return buf.getvalue()


def grid_csv_bytes(run: FieldRun, grid_m: float = 20.0) -> bytes:
    """Point grid (lat/lon + rates) at approximately `grid_m` spacing for point-based controllers."""
    step = max(1, int(round(grid_m / run.tile.resolution)))
    zr = run.zoning.zone_raster
    rows, cols = np.nonzero(zr > 0)
    keep = (rows % step == step // 2) & (cols % step == step // 2)
    rows, cols = rows[keep], cols[keep]
    t = run.tile.transform
    xs = t.c + (cols + 0.5) * t.a
    ys = t.f + (rows + 0.5) * t.e
    pts = gpd.GeoSeries(gpd.points_from_xy(xs, ys), crs=run.tile.crs.to_string()).to_crs("EPSG:4326")
    rates = run.rx.set_index("zone_id")
    zone_ids = zr[rows, cols]
    df = pd.DataFrame(
        {
            "lat": pts.y.round(7),
            "lon": pts.x.round(7),
            "zone_id": zone_ids,
            "n_kg_ha": rates.loc[zone_ids, "n_rate_kg_ha"].to_numpy(),
            "n_lb_ac": rates.loc[zone_ids, "n_rate_lb_ac"].to_numpy(),
            "product_lb_ac": rates.loc[zone_ids, "product_lb_ac"].to_numpy(),
        }
    )
    return df.to_csv(index=False).encode()


def report_json_bytes(run: FieldRun) -> bytes:
    payload = {
        "generated": date.today().isoformat(),
        "settings": asdict(run.settings),
        "scene_id": run.tile.scene_id,
        "imagery_date": run.tile.acquired.isoformat() if run.tile.acquired else None,
        "imagery_source": run.tile.source,
        "soil_source": run.soil_source,
        "weather": asdict(run.weather),
        "k_scores": run.zoning.k_scores,
        "zones": json.loads(run.zoning.profile.round(4).to_json(orient="records")),
        "prescription": json.loads(run.rx.to_json(orient="records")),
        "vs_flat_rate": run.comparison,
        "risk_limit": RISK_LIMIT,
        "warnings": run.warnings,
        "boundary": mapping(run.boundary),
    }
    return json.dumps(payload, indent=2, default=str).encode()


def _ndvi_rgba(ndvi: npt.NDArray[np.float32]) -> npt.NDArray[np.uint8]:
    """Red-yellow-green ramp for NDVI 0.0-0.9, transparent where NaN."""
    stops = np.array([0.0, 0.3, 0.55, 0.9])
    colors = np.array([[165, 0, 38], [253, 174, 97], [217, 239, 139], [0, 104, 55]], dtype=np.float64)
    v = np.clip(np.nan_to_num(ndvi, nan=0.0), stops[0], stops[-1])
    rgba = np.zeros(ndvi.shape + (4,), dtype=np.uint8)
    for ch in range(3):
        rgba[..., ch] = np.interp(v, stops, colors[:, ch]).astype(np.uint8)
    rgba[..., 3] = np.where(np.isfinite(ndvi), 200, 0).astype(np.uint8)
    return rgba


def ndvi_overlay(run: FieldRun) -> tuple[npt.NDArray[np.uint8], list[list[float]]]:
    """Reproject NDVI to EPSG:4326 for a Leaflet image overlay."""
    idx = compute_indices(run.tile)
    src = np.where(idx.valid_mask, idx.ndvi, np.nan).astype(np.float32)
    h, w = src.shape
    left, bottom, right, top = run.tile.bounds
    dst_transform, dw, dh = calculate_default_transform(run.tile.crs, "EPSG:4326", w, h, left, bottom, right, top)
    dst = np.full((dh, dw), np.nan, dtype=np.float32)
    reproject(
        src,
        dst,
        src_transform=run.tile.transform,
        src_crs=run.tile.crs,
        dst_transform=dst_transform,
        dst_crs="EPSG:4326",
        resampling=Resampling.nearest,
        src_nodata=np.nan,
        dst_nodata=np.nan,
    )
    west, south, east, north = array_bounds(dh, dw, dst_transform)
    return _ndvi_rgba(dst), [[south, west], [north, east]]


def _base_map(center: tuple[float, float], zoom: int) -> folium.Map:
    m = folium.Map(location=list(center), zoom_start=zoom, tiles=None, control_scale=True)
    folium.TileLayer(ESRI_IMAGERY, attr="Esri, Maxar, Earthstar Geographics", name="Satellite", max_zoom=19).add_to(m)
    folium.TileLayer("OpenStreetMap", name="Streets").add_to(m)
    Fullscreen().add_to(m)
    return m


def build_input_map(boundary: BaseGeometry | None) -> folium.Map:
    center = (boundary.centroid.y, boundary.centroid.x) if boundary is not None else DEFAULT_CENTER
    m = _base_map(center, 15 if boundary is not None else 14)
    if boundary is not None:
        folium.GeoJson(mapping(boundary), name="Field boundary", style_function=lambda _: {"color": "#FFD400", "weight": 3, "fillOpacity": 0.05}).add_to(m)
    Draw(
        export=False,
        position="topleft",
        draw_options={"polyline": False, "circle": False, "circlemarker": False, "marker": False, "polygon": True, "rectangle": True},
        edit_options={"edit": False},
    ).add_to(m)
    folium.LayerControl(collapsed=True).add_to(m)
    return m


def build_result_map(run: FieldRun) -> folium.Map:
    b = run.boundary
    m = _base_map((b.centroid.y, b.centroid.x), 15)
    minx, miny, maxx, maxy = b.bounds
    m.fit_bounds([[miny, minx], [maxy, maxx]])

    rgba, bounds = ndvi_overlay(run)
    folium.raster_layers.ImageOverlay(rgba, bounds=bounds, name="NDVI (Sentinel-2)", opacity=0.85, show=False, mercator_project=True).add_to(m)

    gdf = prescription_polygons(run)
    gdf_json = json.loads(gdf.drop(columns=["advisory"]).to_json())
    tooltip_fields = ["zone_name", "area_ha", "n_rate_kg_ha", "n_rate_lb_ac", "product_lb_ac", "sim_leach_risk"]
    aliases = ["Zone", "Area (ha)", "N (kg/ha)", "N (lb/ac)", "Product (lb/ac)", "Leach risk"]
    folium.GeoJson(
        gdf_json,
        name="Management zones",
        style_function=lambda f: {"fillColor": f["properties"]["color"], "color": "#222", "weight": 1, "fillOpacity": 0.6},
        tooltip=folium.GeoJsonTooltip(fields=tooltip_fields, aliases=aliases, localize=True),
    ).add_to(m)

    rates = gdf["n_rate_kg_ha"].astype(float)
    lo, hi = float(rates.min()), float(rates.max())
    cmap = bcm.LinearColormap(["#FFFFCC", "#FD8D3C", "#800026"], vmin=lo, vmax=max(hi, lo + 1.0), caption="Prescribed N (kg/ha)")
    folium.GeoJson(
        gdf_json,
        name="N prescription",
        show=False,
        style_function=lambda f: {"fillColor": cmap(float(f["properties"]["n_rate_kg_ha"])), "color": "#222", "weight": 1, "fillOpacity": 0.75},
        tooltip=folium.GeoJsonTooltip(fields=tooltip_fields, aliases=aliases, localize=True),
    ).add_to(m)
    cmap.add_to(m)
    folium.GeoJson(mapping(b), name="Field boundary", style_function=lambda _: {"color": "#FFD400", "weight": 3, "fillOpacity": 0.0}).add_to(m)
    folium.LayerControl(collapsed=False).add_to(m)
    return m


# ======================================================================================
# Streamlit UI
# ======================================================================================
def main() -> None:  # pragma: no cover - UI glue
    import streamlit as st
    from streamlit_folium import st_folium

    st.set_page_config(page_title="Precision N & Runoff Advisor", page_icon="🌱", layout="wide")

    @st.cache_resource(show_spinner="Preparing the nitrogen model (first run trains it; ~1-2 min)…")
    def get_model(crop_name: str, samples: int) -> tuple[DualObjectiveRegressor, CropProfile, SimulatorConfig]:
        model_dir = MODELS_DIR / crop_name
        if (model_dir / "model_meta.json").exists():
            try:
                return DualObjectiveRegressor.load(model_dir)
            except Exception as exc:
                LOGGER.warning("Could not load saved model (%s); retraining.", exc)
        crop = CROPS[crop_name]
        cfg = SimulatorConfig()
        model = train_model(crop, samples, cfg, seed=0)
        model.save(model_dir, crop, cfg)
        return model, crop, cfg

    ss = st.session_state
    ss.setdefault("boundary", None)
    ss.setdefault("run", None)

    st.title("🌱 Precision Nitrogen & Soil Runoff Advisor")
    st.caption(
        "Zone-level nitrogen prescriptions from Sentinel-2 imagery, SoilGrids soil data and the 5-day forecast — "
        f"maximising crop response while keeping leaching/runoff risk below {RISK_LIMIT:.2f}."
    )

    # ---------------- Sidebar ----------------
    with st.sidebar:
        st.header("1 · Data")
        mode_label = st.radio("Data source", ["Synthetic demo (offline)", "Live data (Sentinel-2 + SoilGrids)"], index=0)
        mode: DataMode = "synthetic" if mode_label.startswith("Synthetic") else "live"
        today = date.today()
        if mode == "live":
            d0, d1 = st.date_input("Imagery window", (today - timedelta(days=30), today))  # type: ignore[misc]
            max_cloud = st.slider("Max scene cloud cover (%)", 5, 80, 30)
            syn_stage, syn_seed = "vegetative", 42
        else:
            d0, d1, max_cloud = today, today, 30
            syn_stage = st.selectbox("Synthetic canopy", ["emergence", "vegetative", "peak"], index=1)
            syn_seed = int(st.number_input("Synthetic field seed", 0, 9999, 42))

        st.header("2 · Crop")
        crop_name = st.selectbox("Crop", list(CROPS), format_func=lambda c: c + (" (provisional)" if CROPS[c].provisional else ""))
        stage = st.selectbox("Growth stage", CROPS[crop_name].stage_names, index=min(2, len(CROPS[crop_name].stages) - 1))
        prior_n = st.number_input("N already applied this season (kg/ha)", 0.0, 400.0, 40.0, step=5.0)
        objective = st.radio("Objective", ["yield", "profit"], horizontal=True, help="Profit uses $0.18/kg grain and $1.10/kg N.")
        product = st.selectbox("Product", ["UAN-32 (32% N)", "UAN-28 (28% N)", "Urea (46% N)", "Anhydrous NH3 (82% N)", "CAN-17 (17% N)"])
        product_name = product.split(" (")[0]
        product_frac = float(product.split("(")[1].split("%")[0]) / 100.0

        st.header("3 · Weather & irrigation")
        use_forecast = st.toggle("Use live Open-Meteo forecast", value=(mode == "live"))
        days = [f"Day {i + 1}" for i in range(FORECAST_DAYS)]
        wx_default = pd.DataFrame({"Rain (mm)": [0.0, 2.0, 25.0, 8.0, 0.0], "ET0 (mm)": [5.0, 4.5, 3.0, 3.5, 5.0], "Irrigation (mm)": [0.0] * FORECAST_DAYS}, index=days)
        st.caption("Rain/ET0 apply when the live forecast is off or unavailable; planned irrigation always applies.")
        wx_table = st.data_editor(wx_default, key="wx_table")

        st.header("4 · Zoning")
        k_min, k_max = st.slider("Zones (k range)", 2, 6, (3, 5))
        min_zone = st.slider("Minimum zone patch (ha)", 0.1, 3.0, 0.5, step=0.1, help="Smaller patches merge into neighbours; match to spreader width/section control.")

        run_clicked = st.button("▶ Run analysis", type="primary", use_container_width=True)

    # ---------------- Boundary input ----------------
    col_map, col_help = st.columns([3, 1])
    with col_help:
        st.subheader("Field boundary")
        st.write("Draw a polygon or rectangle on the map, or upload a boundary file.")
        upload = st.file_uploader("GeoJSON or zipped Shapefile", type=["geojson", "json", "zip"])
        if upload is not None:
            try:
                ss.boundary = read_uploaded_boundary(upload.name, upload.getvalue())
                st.success(f"Loaded boundary: {geodesic_area_ha(ss.boundary):.1f} ha")
            except Exception as exc:
                st.error(f"Could not read boundary: {exc}")
        if ss.boundary is not None:
            st.metric("Boundary area", f"{geodesic_area_ha(ss.boundary):.1f} ha")
            if st.button("Clear boundary"):
                ss.boundary, ss.run = None, None
                st.rerun()
        if mode == "synthetic":
            st.info("Synthetic mode uses a demo field near Chualar (Salinas Valley). A boundary you draw there is honoured.")

    with col_map:
        drawn = st_folium(build_input_map(ss.boundary), height=420, use_container_width=True, key="input_map", returned_objects=["last_active_drawing"])
        if drawn and drawn.get("last_active_drawing"):
            geom = shape(drawn["last_active_drawing"]["geometry"]).buffer(0)
            if geom.geom_type in ("Polygon", "MultiPolygon") and (ss.boundary is None or not geom.equals(ss.boundary)):
                ss.boundary = geom
                st.rerun()

    # ---------------- Run ----------------
    if run_clicked:
        settings = RunSettings(
            mode=mode,
            crop_name=crop_name,
            stage=stage,
            prior_n=float(prior_n),
            objective=objective,  # type: ignore[arg-type]
            product_name=product_name,
            product_n_fraction=product_frac,
            k_min=int(k_min),
            k_max=int(k_max),
            min_zone_ha=float(min_zone),
            imagery_start=str(d0),
            imagery_end=str(d1),
            max_cloud=float(max_cloud),
            synthetic_stage=syn_stage,
            synthetic_seed=int(syn_seed),
            use_forecast=bool(use_forecast),
            manual_rain=tuple(float(v) for v in wx_table["Rain (mm)"]),
            manual_et0=tuple(float(v) for v in wx_table["ET0 (mm)"]),
            irrigation=tuple(float(v) for v in wx_table["Irrigation (mm)"]),
        )
        model, crop, sim_cfg = get_model(crop_name, 20_000)
        try:
            with st.status("Running pipeline…", expanded=True) as status:
                st.write("Phase 1 · imagery & spectral indices · Phase 2 · soil & zones · Phase 3 · N optimisation")
                ss.run = run_pipeline(settings, ss.boundary, model, crop, sim_cfg)
                status.update(label="Analysis complete", state="complete")
        except Exception as exc:
            ss.run = None
            st.error(f"Pipeline failed: {exc}")

    run: FieldRun | None = ss.run
    if run is None:
        st.stop()

    # ---------------- Results ----------------
    for w in run.warnings:
        st.warning(w)
    rx = run.rx
    total_n = float((rx["n_rate_kg_ha"] * rx["area_ha"]).sum())
    total_area = float(rx["area_ha"].sum())
    comp = run.comparison
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Field area (zoned)", f"{total_area:.1f} ha")
    c2.metric("Avg N rate", f"{total_n / max(total_area, 1e-9):.0f} kg/ha", f"{total_n / max(total_area, 1e-9) * KG_HA_TO_LB_AC:.0f} lb/ac", delta_color="off")
    c3.metric("N vs flat rate", f"{comp['n_applied_vr_kg']:,.0f} kg", f"{comp['n_applied_vr_kg'] - comp['n_applied_flat_kg']:,.0f} kg", delta_color="inverse")
    c4.metric("Expected N lost (5 days)", f"{comp['n_lost_vr_kg']:,.0f} kg", f"{comp['n_lost_vr_kg'] - comp['n_lost_flat_kg']:,.0f} kg vs flat", delta_color="inverse")

    map_col, info_col = st.columns([3, 2])
    with map_col:
        st_folium(build_result_map(run), height=560, use_container_width=True, key="result_map", returned_objects=[])
    with info_col:
        st.subheader("Prescription")
        show = rx[["zone_name", "area_ha", "n_rate_kg_ha", "n_rate_lb_ac", "product_lb_ac", "n_unconstrained_kg_ha", "sim_leach_risk"]].rename(
            columns={
                "zone_name": "Zone",
                "area_ha": "ha",
                "n_rate_kg_ha": "N kg/ha",
                "n_rate_lb_ac": "N lb/ac",
                "product_lb_ac": f"{run.settings.product_name} lb/ac",
                "n_unconstrained_kg_ha": "N if risk ignored",
                "sim_leach_risk": "Risk",
            }
        )
        st.dataframe(show, hide_index=True)
        st.subheader("Advisories")
        for r in rx.itertuples():
            st.markdown(f"**{r.zone_name}** — {r.advisory}")

    tab_wx, tab_zones, tab_model = st.tabs(["Forecast", "Zone soil & spectral profile", "Model & data provenance"])
    with tab_wx:
        wx_df = pd.DataFrame(
            {"Rain (mm)": run.weather.precip_mm, "Irrigation (mm)": run.weather.irrigation_mm, "ET0 (mm)": run.weather.et0_mm},
            index=list(run.weather.dates),
        )
        st.bar_chart(wx_df[["Rain (mm)", "Irrigation (mm)"]])
        st.caption(f"Source: {run.weather.source}")
    with tab_zones:
        prof_cols = ["zone_name", "area_ha", "texture", "drainage", "sand_pct", "clay_pct", "soc_gkg", "ph", "awc_mm_0_30cm", "ksat_mm_h", "ndvi", "moisture_anomaly", "leaching_index"]
        st.dataframe(run.zoning.profile[prof_cols].round(3), hide_index=True)
        st.json(run.zoning.k_scores, expanded=False)
    with tab_model:
        model, crop, _ = get_model(run.settings.crop_name, 20_000)
        st.write(
            {
                "imagery": f"{run.tile.source} · {run.tile.scene_id} · {run.tile.acquired.date() if run.tile.acquired else 'n/a'}",
                "clear pixels in field": f"{run.tile.valid_fraction:.1%}",
                "soil": run.soil_source,
                "crop profile": crop.source,
                "surrogate validation": model.metrics,
            }
        )

    st.subheader("Downloads")
    d1c, d2c, d3c, d4c = st.columns(4)
    stem = f"rx_{run.settings.crop_name}_{date.today():%Y%m%d}"
    d1c.download_button("Shapefile (.zip)", shapefile_zip_bytes(run), f"{stem}_shp.zip", "application/zip", use_container_width=True)
    d2c.download_button("Point grid CSV", grid_csv_bytes(run), f"{stem}_grid.csv", "text/csv", use_container_width=True)
    d3c.download_button("Zone table CSV", rx.to_csv(index=False).encode(), f"{stem}_zones.csv", "text/csv", use_container_width=True)
    d4c.download_button("Audit report JSON", report_json_bytes(run), f"{stem}_report.json", "application/json", use_container_width=True)
    st.caption(
        "Advisory tool. Verify rates with local agronomic guidance and in-season soil/tissue tests; follow label and regulatory limits."
    )


if __name__ == "__main__":
    main()
